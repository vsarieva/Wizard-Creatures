const express = require('express');
const path = require('path');
const {PORT, DB_URL} = require('../src/constants.js');
const routes = require('./router.js');
const handlebars = require('express-handlebars');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const {auth} = require('./middlewares/authMiddleware.js');

//Local variables
const app = express();

//Express configuration
app.use(express.static(path.resolve(__dirname, './public')));
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(auth);


//Handlebars configuration
app.engine('hbs', handlebars.engine({extname: 'hbs'}));
app.set('view engine', 'hbs');
app.set('views', 'src/views');

//Database connection
async function dbConnect(){
   await(mongoose.connect(DB_URL));
}

dbConnect()
.then(console.log('Successfylly connected to the DB~!'))
.catch(err => console.log(`Error while connecting to the db. Error: ${err}`));

//Routes
app.use(routes);

app.listen(PORT, () => console.log(`The server is listening on port ${PORT}`))